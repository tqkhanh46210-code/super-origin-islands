package com.originisle.android.cards

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.Icon
import androidx.core.graphics.PathParser

/**
 * Lucide icons (https://lucide.dev, ISC licence) — the same set morphicons.com plays with.
 * Each icon is the list of SVG path `d` strings of its 24x24 stroke design (stroke 2, round caps).
 * [render] draws them straight into a bitmap, so the island shows a crisp, correctly coloured icon
 * (no tint tricks, no animation frames).
 *
 * To add an icon: open it on lucide.dev, "Copy SVG", and paste each <path d="..."> / convert each
 * <line>/<circle> to a path, as an entry below.
 */
object LucideIcons {
    val Download = listOf("M12 15V3", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", "m7 10 5 5 5-5")
    val Bell = listOf("M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9", "M10.3 21a1.94 1.94 0 0 0 3.4 0")
    val BellRing = listOf(
        "M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9", "M10.3 21a1.94 1.94 0 0 0 3.4 0",
        "M4 2C2.8 3.7 2 5.7 2 8", "M22 8c0-2.3-.8-4.3-2-6",
    )
    val BellOff = listOf(
        "M8.7 3A6 6 0 0 1 18 8a21.3 21.3 0 0 0 .6 5", "M17 17H3s3-2 3-9a4.67 4.67 0 0 1 .3-1.7",
        "M10.3 21a1.94 1.94 0 0 0 3.4 0", "m2 2 20 20",
    )
    val Moon = listOf("M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z")
    val Vibrate = listOf(
        "m2 8 2 2-2 2 2 2 2-2", "m22 8-2 2 2 2-2 2-2-2",
        "M8 8v8a2 2 0 0 0 2 2h4a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2Z",
    )

    fun render(paths: List<String>, color: Int, size: Int = 96, strokeWidth: Float = 2f, padding: Float = 2f): Bitmap {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val scale = size / (24f + padding * 2)
        c.scale(scale, scale)
        c.translate(padding, padding)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            this.color = color
            this.strokeWidth = strokeWidth
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }
        paths.forEach { d ->
            val p: Path? = runCatching { PathParser.createPathFromPathData(d) }.getOrNull()
            if (p != null) c.drawPath(p, paint)
        }
        return bmp
    }

    fun icon(paths: List<String>, color: Int, size: Int = 96, strokeWidth: Float = 2f): Icon =
        Icon.createWithBitmap(render(paths, color, size, strokeWidth))
}
