package com.originisle.android.cards

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Path
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.AnimatedStateListDrawable
import android.graphics.drawable.AnimatedVectorDrawable
import android.graphics.drawable.AnimationDrawable
import android.graphics.drawable.Icon
import androidx.core.graphics.drawable.toBitmap
import com.originisle.android.MainActivity

/**
 * A content intent that opens the SOURCE app's own notification target — or, if the source
 * notification has none, falls back to just launching the app. vivo requires every SuperX post to
 * carry a content intent or it silently rejects it; this is that fallback.
 */
internal fun fallbackClickIntent(context: Context, pkg: String): PendingIntent {
    val launch = context.packageManager.getLaunchIntentForPackage(pkg) ?: Intent(context, MainActivity::class.java)
    return PendingIntent.getActivity(
        context, pkg.hashCode(), launch,
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )
}

/**
 * Cap a bitmap's longer side before it's ever wrapped in an [android.graphics.drawable.Icon] and
 * crosses a Binder call (`startService()`/`notify()` both parcel the Icon). A source notification's
 * bitmap isn't guaranteed to be icon-sized — a video's own frame (e.g. Firefox playback) can be
 * full-resolution — and passing it as-is throws "Could not copy bitmap to parcel blob" and crashes,
 * which then crash-loops the whole listener since it re-casts on every reconnect.
 */
internal fun shrinkForIcon(bitmap: Bitmap, maxDimension: Int = 200): Bitmap {
    val w = bitmap.width
    val h = bitmap.height
    if (w <= maxDimension && h <= maxDimension) return bitmap
    val scale = maxDimension.toFloat() / maxOf(w, h)
    return Bitmap.createScaledBitmap(bitmap, (w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1), true)
}

/**
 * An [Icon] that's safe to put in an Intent. Bitmap-backed icons (a contact's avatar, a chat's large
 * icon) can be full-size and blow the parcel up exactly like [shrinkForIcon] describes, and URI-backed
 * ones point into the source app where SystemUI may not be allowed to read them — so both are
 * rendered once and shrunk here. Resource icons are just a package + id and pass through untouched.
 */
internal fun parcelSafeIcon(context: Context, icon: Icon?, maxDimension: Int = 144): Icon? {
    if (icon == null) return null
    if (icon.type == Icon.TYPE_RESOURCE) return icon
    return runCatching {
        val drawable = icon.loadDrawable(context) ?: return null
        val w = drawable.intrinsicWidth.takeIf { it > 0 } ?: maxDimension
        val h = drawable.intrinsicHeight.takeIf { it > 0 } ?: maxDimension
        val scale = minOf(1f, maxDimension.toFloat() / maxOf(w, h))
        Icon.createWithBitmap(
            drawable.toBitmap((w * scale).toInt().coerceAtLeast(1), (h * scale).toInt().coerceAtLeast(1)),
        )
    }.getOrNull()
}

/** "125" -> "02:05", "3725" -> "01:02:05" — a stopwatch-style elapsed-time string. */
internal fun formatElapsed(totalSeconds: Long): String {
    val s = totalSeconds % 60
    val m = (totalSeconds / 60) % 60
    val h = totalSeconds / 3600
    return if (h > 0) "%02d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}


/**
 * FIX (icon bị lẹm): the raw app icon is an adaptive/square resource (Telegram = white square
 * background layer). The island draws it into a round slot and crops one edge. Render it ONCE to a
 * square, circle-clipped bitmap so every card shows a clean round icon whatever the source app is.
 */
internal fun roundedAppIcon(context: Context, pkg: String, size: Int = 128): Icon? = runCatching {
    val d = context.packageManager.getApplicationIcon(pkg)
    val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
    val c = Canvas(bmp)
    val clip = Path().apply { addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW) }
    c.clipPath(clip)
    // Adaptive icons draw a 108dp canvas of which only the centre 72dp is visible: oversize the
    // bounds so the visible part fills the circle instead of leaving a white square margin.
    val inset = if (d is AdaptiveIconDrawable) -(size * 0.25f).toInt() else 0
    d.setBounds(inset, inset, size - inset, size - inset)
    d.draw(c)
    Icon.createWithBitmap(bmp)
}.getOrNull()


/**
 * FIX (icon lẹm ở MỌI app): last line of defence applied in PlaygroundService to every icon that
 * reaches the island slots (left, right/capsule, large, sub-image). The island crops whatever it is
 * given to a square/round slot, so non-square bitmaps, adaptive icons with a square background and
 * wide logos all lose an edge. Here everything becomes a square, transparent-padded bitmap:
 *  - adaptive icons -> oversized so the visible area fills a circle (no white square corners)
 *  - any other drawable/bitmap -> scaled to FIT (never cropped) and centred with a small margin
 */
internal fun islandSafeIcon(context: Context, icon: Icon?, size: Int = 128): Icon? {
    if (icon == null) return null
    return runCatching {
        val d = icon.loadDrawable(context) ?: return icon
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (d is AdaptiveIconDrawable) {
            c.clipPath(Path().apply { addCircle(size / 2f, size / 2f, size / 2f, Path.Direction.CW) })
            val inset = -(size * 0.25f).toInt()
            d.setBounds(inset, inset, size - inset, size - inset)
        } else {
            val w = d.intrinsicWidth.takeIf { it > 0 } ?: size
            val h = d.intrinsicHeight.takeIf { it > 0 } ?: size
            val box = size * 0.92f
            val scale = box / maxOf(w, h)
            val dw = (w * scale).toInt().coerceAtLeast(1)
            val dh = (h * scale).toInt().coerceAtLeast(1)
            val l = (size - dw) / 2
            val t = (size - dh) / 2
            d.setBounds(l, t, l + dw, t + dh)
        }
        d.draw(c)
        Icon.createWithBitmap(bmp)
    }.getOrDefault(icon)
}


/** True when the notification's small icon is an animated drawable (Play Store's download arrow...). */
internal fun isAnimatedIcon(context: Context, icon: Icon?): Boolean = runCatching {
    val d = icon?.loadDrawable(context)
    d is AnimationDrawable || d is AnimatedVectorDrawable || d is AnimatedStateListDrawable
}.getOrDefault(false)

/**
 * FIX (icon tải xuống bị khựng): Play Store & co. post an ANIMATED small icon (frame-list arrow with
 * blank frames). The island plays it at the frame rate of that list, so it stutters. Replace it with
 * a single crisp static frame: our own blue download arrow for progress/download notifications,
 * otherwise the last frame of the source animation.
 */
internal fun smoothSmallIcon(context: Context, small: Icon?, progressy: Boolean, size: Int = 96): Icon? {
    if (small == null || !isAnimatedIcon(context, small)) return null
    return runCatching {
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        if (progressy) {
            // Lucide "download" (morphicons.com set), stroke 2, in the original cyan-blue.
            c.drawBitmap(LucideIcons.render(LucideIcons.Download, android.graphics.Color.parseColor("#FF30B4F0"), size), 0f, 0f, null)
        } else {
            val src = small.loadDrawable(context)!!
            val frame = (src as? AnimationDrawable)?.let { it.getFrame(it.numberOfFrames - 1) } ?: src
            frame.setBounds(0, 0, size, size)
            frame.draw(c)
        }
        Icon.createWithBitmap(bmp)
    }.getOrNull()
}
