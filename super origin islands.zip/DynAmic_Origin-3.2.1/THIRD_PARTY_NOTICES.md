# Third-party notices

## Lucide icons (cards/LucideIcons.kt)
ISC License — Copyright (c) 2026 Lucide Icons and Contributors. https://github.com/lucide-icons/lucide/blob/main/LICENSE
Icons were chosen via morphicons.com (MIT, (c) Guillermo), whose playground uses Lucide.
