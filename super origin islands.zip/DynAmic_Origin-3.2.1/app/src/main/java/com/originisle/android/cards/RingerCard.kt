package com.originisle.android.cards

import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import androidx.annotation.DrawableRes
import com.originisle.android.R
import com.originisle.android.island.OriginIslandConstants
import com.originisle.android.island.PlaygroundService
import com.originisle.android.ui.Lang
import com.originisle.android.ui.PREFS_NAME

/**
 * Ringer / Do-Not-Disturb card (kiểu HyperOS / iOS): flips on the island for ~2.5 s whenever the
 * phone goes Silent, Vibrate, back to Ringing, or Do Not Disturb is switched on/off.
 *
 *  - Silent  : red bell-slash   "Chế độ im lặng đã bật"
 *  - Vibrate : orange vibrate   "Chế độ rung đã bật"
 *  - Ring    : green bell       "Chuông đã bật"
 *  - DND     : purple moon      "Không làm phiền đã bật / tắt"
 *
 * Only system broadcasts are used, so no permission is needed. The first state read after
 * start() is a baseline and never shows a card. Toggle: Settings -> Cards -> "Ringer / DND card"
 * (pref key `cast_ringer`, default on).
 */
object RingerCard {

    /** Fixed cast id, next to [FlashlightCard.ID]. */
    const val ID = 35010

    private const val BRIEF_MS = 2800L
    private const val RED = "#FFFF3B30"
    private const val ORANGE = "#FFFF9500"
    private const val GREEN = "#FF34C759"
    private const val PURPLE = "#FF8E7CFF"
    private const val GRAY = "#FF9A9AA5"

    private val handler = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var lastRinger = -1
    private var lastFilter = -1
    private var hideTask: Runnable? = null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            runCatching { onChanged(context.applicationContext, intent.action) }
        }
    }

    fun start(context: Context) {
        if (app != null) return
        val ctx = context.applicationContext
        app = ctx
        lastRinger = ctx.getSystemService(AudioManager::class.java)?.ringerMode ?: -1
        lastFilter = ctx.getSystemService(NotificationManager::class.java)?.currentInterruptionFilter ?: -1
        val filter = IntentFilter().apply {
            addAction(AudioManager.RINGER_MODE_CHANGED_ACTION)
            addAction(NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED)
        }
        runCatching { ctx.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED) }
    }

    fun stop() {
        val ctx = app ?: return
        runCatching { ctx.unregisterReceiver(receiver) }
        hideTask?.let(handler::removeCallbacks)
        hideTask = null
        app = null
    }

    private fun onChanged(context: Context, action: String?) {
        val prefs = context.getSharedPreferences(PREFS_NAME, 0)
        val enabled = prefs.getBoolean("cast_notifications", false) && prefs.getBoolean("cast_ringer", true)

        val ringer = context.getSystemService(AudioManager::class.java)?.ringerMode ?: return
        val dnd = context.getSystemService(NotificationManager::class.java)?.currentInterruptionFilter ?: return

        val ringerChanged = ringer != lastRinger
        val dndChanged = dnd != lastFilter
        val dndWasOn = lastFilter > NotificationManager.INTERRUPTION_FILTER_ALL
        val dndIsOn = dnd > NotificationManager.INTERRUPTION_FILTER_ALL
        lastRinger = ringer
        lastFilter = dnd
        if (!enabled) return

        val vi = Lang.currentLang(context) == "vi"
        when {
            action == NotificationManager.ACTION_INTERRUPTION_FILTER_CHANGED && dndChanged && dndWasOn != dndIsOn ->
                if (dndIsOn) show(context, R.drawable.ic_ringer_moon, PURPLE,
                    if (vi) "Không làm phiền đã bật" else "Do Not Disturb on",
                    if (vi) "Không làm phiền" else "Do Not Disturb")
                else show(context, R.drawable.ic_ringer_moon, GRAY,
                    if (vi) "Không làm phiền đã tắt" else "Do Not Disturb off",
                    if (vi) "Đã tắt" else "Off")
            ringerChanged -> when (ringer) {
                AudioManager.RINGER_MODE_SILENT -> show(context, R.drawable.ic_ringer_silent, RED,
                    if (vi) "Chế độ im lặng đã bật" else "Silent mode on",
                    if (vi) "Im lặng" else "Silent")
                AudioManager.RINGER_MODE_VIBRATE -> show(context, R.drawable.ic_ringer_vibrate, ORANGE,
                    if (vi) "Chế độ rung đã bật" else "Vibrate mode on",
                    if (vi) "Rung" else "Vibrate")
                else -> show(context, R.drawable.ic_ringer_bell, GREEN,
                    if (vi) "Chuông đã bật" else "Ringer on",
                    if (vi) "Chuông" else "Ring")
            }
        }
    }

    /** Lucide stroke icon (morphicons.com set) drawn in [color], so the island shows the colour. */
    private fun coloredIcon(context: Context, @DrawableRes res: Int, color: Int, size: Int = 96): Icon? = runCatching {
        val paths = when (res) {
            R.drawable.ic_ringer_silent -> LucideIcons.BellOff
            R.drawable.ic_ringer_vibrate -> LucideIcons.Vibrate
            R.drawable.ic_ringer_bell -> LucideIcons.BellRing
            R.drawable.ic_ringer_moon -> LucideIcons.Moon
            else -> return null
        }
        LucideIcons.icon(paths, color, size)
    }.getOrNull()

    private fun show(context: Context, @DrawableRes res: Int, colorHex: String, title: String, chip: String) {
        val color = android.graphics.Color.parseColor(colorHex)
        val icon = coloredIcon(context, res, color) ?: Icon.createWithResource(context, res)
        val click = PendingIntent.getActivity(
            context, ID, Intent(android.provider.Settings.ACTION_SOUND_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val intent = Intent(context, PlaygroundService::class.java).apply {
            action = PlaygroundService.ACTION_START
            putExtra("id", ID)
            // Live: our own timer decides when it goes, not the "Hide after" setting.
            putExtra("is_ongoing", true)
            putExtra("oi_scene", "NAVIGATION")
            putExtra("oi_template", OriginIslandConstants.TEMPLATE_BASE) // 4
            putExtra("title", title)
            putExtra("text", "")
            // Pill: coloured icon left of the camera, short label right of it (như ảnh HyperOS).
            putExtra("oi_left_content", "")
            putExtra("oi_left_icon", icon)
            putExtra("oi_large_icon", icon)
            putExtra("oi_right_template", OriginIslandConstants.TEMPLATE_RIGHT_ISLAND_TEXT_ICON) // 4
            putExtra("oi_show_right_icon", false)
            putExtra("oi_right_content", chip)
            putExtra("status_chip_text", chip)
            putExtra("icon_res", res)
            putExtra("oi_fg_color", colorHex)
            putExtra("oi_light_color", colorHex)
            putExtra("oi_force_show", true)
            putExtra("click_resp", click)
        }
        context.startService(intent)
        hideTask?.let(handler::removeCallbacks)
        hideTask = Runnable { hide(context) }.also { handler.postDelayed(it, BRIEF_MS) }
    }

    private fun hide(context: Context) {
        hideTask?.let(handler::removeCallbacks)
        hideTask = null
        context.startService(
            Intent(context, PlaygroundService::class.java)
                .setAction(PlaygroundService.ACTION_CANCEL)
                .putExtra("id", ID)
                .putExtra("oi_scene", "NAVIGATION"),
        )
    }
}
