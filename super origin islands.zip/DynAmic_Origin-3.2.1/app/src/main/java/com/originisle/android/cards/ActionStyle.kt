package com.originisle.android.cards

import android.app.Notification
import android.graphics.Color
import android.graphics.drawable.Icon

/**
 * One consistent look for every button on an expanded island card (media controls, "Cancel",
 * "Manage notifications", call buttons ...): a Lucide icon (morphicons.com set) drawn in the same
 * box, stroke and colour, picked from what the button MEANS rather than from whatever icon the
 * source app attached (those were often grey, wrong, or tiny — e.g. a "play" triangle on
 * "Manage notifications"). Labels are shortened so they never wrap onto a second line.
 */
object ActionStyle {

    private val SkipBack = listOf("M19 20 9 12l10-8v16z", "M5 19V5")
    private val SkipForward = listOf("m5 4 10 8-10 8V4z", "M19 5v14")
    private val Pause = listOf(
        "M15 4h2a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1h-2a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z",
        "M7 4h2a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1Z",
    )
    private val Play = listOf("M6 3 20 12 6 21Z")
    private val Square = listOf("M5 3h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z")
    private val X = listOf("M18 6 6 18", "m6 6 12 12")
    private val Check = listOf("M20 6 9 17l-5-5")
    private val Trash = listOf("M3 6h18", "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", "M10 11v6", "M14 11v6")
    private val Clock = listOf("M12 6v6l4 2", "M22 12a10 10 0 1 1-20 0 10 10 0 0 1 20 0")
    private val ArrowRight = listOf("M5 12h14", "m12 5 7 7-7 7")
    private val ExternalLink = listOf("M15 3h6v6", "M10 14 21 3", "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6")
    private val Phone = listOf("M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z")
    private val PhoneOff = listOf(
        "M10.68 13.31a16 16 0 0 0 3.41 2.6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7 2 2 0 0 1 1.72 2v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.42 19.42 0 0 1-3.33-2.67m-2.67-3.34a19.79 19.79 0 0 1-3.07-8.63A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91",
        "m2 2 20 20",
    )
    private val Settings = listOf(
        "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
        "M15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0z",
    )

    /** Keyword groups, checked in order (so "tạm dừng" is Pause before "dừng" could mean Stop). */
    private val RULES: List<Pair<List<String>, List<String>>> = listOf(
        listOf("tạm dừng", "pause") to Pause,
        listOf("tiếp tục", "resume", "phát", "play") to Play,
        listOf("trước", "prev", "rewind") to SkipBack,
        listOf("tiếp", "next", "forward") to SkipForward,
        listOf("stop", "dừng") to Square,
        listOf("decline", "từ chối", "hang up", "end call", "kết thúc", "reject") to PhoneOff,
        listOf("answer", "accept", "chấp nhận", "nghe máy", "call", "gọi") to Phone,
        listOf("cancel", "hủy", "huỷ", "dismiss", "đóng", "close", "bỏ qua", "skip", "exit", "thoát") to X,
        listOf("manage", "quản lý", "setting", "cài đặt") to Settings,
        listOf("mark as read", "đã đọc", "đánh dấu", "done", "xong", "complete", "hoàn tất") to Check,
        listOf("delete", "xóa", "xoá", "remove", "gỡ") to Trash,
        listOf("snooze", "báo lại", "hoãn") to Clock,
        listOf("open", "mở", "view", "xem", "detail", "chi tiết") to ExternalLink,
    )

    private fun pathsFor(title: String): List<String> {
        val t = title.lowercase().trim()
        return RULES.firstOrNull { (keys, _) -> keys.any { t.contains(it) } }?.second ?: ArrowRight
    }

    /** Black Lucide icon (the card's buttons are white with black content). Same box for every button. */
    fun icon(action: Notification.Action): Icon =
        LucideIcons.icon(pathsFor(action.title?.toString().orEmpty()), Color.parseColor("#FF1C1C1E"), 96, 2.25f)

    /** Explicit short forms first, then keep whole words until the per-button limit. */
    fun label(action: Notification.Action, buttonCount: Int): String {
        val raw = action.title?.toString()?.trim().orEmpty()
        when (raw.lowercase()) {
            "tạm dừng" -> return "Dừng"
            "quản lý thông báo" -> return "Quản lý"
            "manage notifications" -> return "Manage"
        }
        val cap = when {
            buttonCount >= 3 -> 7
            buttonCount == 2 -> 12
            else -> 22
        }
        if (raw.length <= cap) return raw
        val words = raw.split(' ').filter { it.isNotEmpty() }
        val sb = StringBuilder()
        for (w in words) {
            val next = if (sb.isEmpty()) w else "$sb $w"
            if (next.length > cap) break
            sb.clear(); sb.append(next)
        }
        return if (sb.isNotEmpty()) sb.toString() else fitPill(raw, cap)
    }

    /**
     * Pill text that would be hard-clipped by the island ("Chế độ im lặng đã", "nsung OneU") is
     * shortened with an ellipsis instead, so it never runs under the camera or past the edge.
     */
    fun fitPill(text: String, max: Int): String =
        if (text.length <= max) text else text.take(max - 1).trimEnd() + "…"
}
